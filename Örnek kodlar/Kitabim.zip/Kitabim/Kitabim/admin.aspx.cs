﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class admin : System.Web.UI.Page
    {
        KitabimEntities database = new KitabimEntities();
        List<katagori> katagoriList = new List<katagori>();
        List<yazar> yazarList = new List<yazar>();
        List<yayinEvi> yayinEviList = new List<yayinEvi>();
        List<ürün> urunList = new List<ürün>();
        txtControl txtControl1 = new txtControl();
        dbOperations db = new dbOperations();

        protected void Page_Load(object sender, EventArgs e)
        {
            //DropDownList_katagori.Items.Clear();
            //DropDownList_yayinEvi.Items.Clear();
            //DropDownList_yazar.Items.Clear();

            katagoriList = database.katagori.ToList();
            yazarList = database.yazar.ToList();
            yayinEviList = database.yayinEvi.ToList();
            urunList = database.ürün.ToList();
            if(DropDownList_katagori.Items.Count == 0)
            {
                for(int i = 0; i < katagoriList.Count; i++)
                {
                    DropDownList_katagori.Items.Add(katagoriList[i].katagori_isim);
                }
            }
            if(DropDownList_yazar.Items.Count == 0)
            {
                for (int i = 0; i < yazarList.Count; i++)
                {
                    DropDownList_yazar.Items.Add(yazarList[i].yazar_isim + " " + yazarList[i].yazar_soyisim);
                }
            }
            if(DropDownList_yayinEvi.Items.Count == 0)
            {
                for(int i = 0; i < yayinEviList.Count; i++)
                {
                    DropDownList_yayinEvi.Items.Add(yayinEviList[i].yayin_evi);
                }
            }

        }
        
        protected void btn_yazarEkle_Click(object sender, EventArgs e)
        {
            bool kontrol = true;
            if(txtControl1.control_isim(txtB_yazarIsmi.Text.ToString()) && txtControl1.control_isim(txtB_yazarSoyismi.Text.ToString()))
            {
                for (int i = 0; i < yazarList.Count; i++)
                {
                    if (txtB_yazarIsmi.Text.ToString().Equals(yazarList[i].yazar_isim) == true && txtB_yazarSoyismi.Text.ToString().Equals(yazarList[i].yazar_soyisim))
                    {
                        kontrol = false;
                    } 
                    
                }
                if (kontrol == true)
                {
                    SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                    SqlCommand cmd = new SqlCommand();
                    String parametre_yazar_ismi = "'" + txtB_yazarIsmi.Text.ToString() + "'";
                    String parametre_yazar_soyismi = "'" + txtB_yazarSoyismi.Text.ToString() + "'";
                    cmd.CommandText = "INSERT INTO yazar (yazar_isim, yazar_soyisim) VALUES (" + parametre_yazar_ismi + ", " + parametre_yazar_soyismi + ");";
                    cmd.Connection = baglanti;
                    baglanti.Open();

                    cmd.ExecuteNonQuery();
                    baglanti.Close();
                }
                else
                {
                    String script = "window.alert('Böyle bir yazar bulunmakta!');";
                    ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
                }
            }
            else
            {
                String script = "window.alert('Yanlış değer girdiniz!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
            }

            
        }

        protected void btn_yayinEviEkle_Click(object sender, EventArgs e)
        {
            bool kontrol = true;
            if (!String.IsNullOrEmpty(txtB_yayinEvi.Text.ToString()))
            {
                for (int i = 0; i < yayinEviList.Count; i++)
                {
                    if (txtB_yayinEvi.Text.ToString().Equals(yayinEviList[i].yayin_evi) == true)
                    {
                        kontrol = false;
                    }

                }
                if (kontrol == true)
                {
                    SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                    SqlCommand cmd = new SqlCommand();
                    String parametre_yayinEvi = "'" + txtB_yayinEvi.Text.ToString() + "'";
                    cmd.CommandText = "INSERT INTO yayinEvi (yayin_evi) VALUES (" + parametre_yayinEvi +");";
                    cmd.Connection = baglanti;
                    baglanti.Open();

                    cmd.ExecuteNonQuery();
                    baglanti.Close();
                    String script = "window.alert('Başarıyla Eklenmiştir');";
                    ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
                }
                else
                {
                    String script = "window.alert('Böyle bir yayın evi bulunmakta!');";
                    ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
                }
            }
            else
            {
                String script = "window.alert('Yanlış değer girdiniz!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
            }
        }

        protected void btn_ekle_katagori_Click(object sender, EventArgs e)
        {
            bool kontrol = true;
            if (txtControl1.control_isim(txtB_katagoriEkle.Text.ToString()) )
            {
                for (int i = 0; i < katagoriList.Count; i++)
                {
                    if (txtB_katagoriEkle.Text.ToString().Equals(katagoriList[i].katagori_isim) == true)
                    {
                        kontrol = false;
                    }

                }
                if (kontrol == true)
                {
                    SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                    SqlCommand cmd = new SqlCommand();
                    String parametre_katagori = "'" + txtB_katagoriEkle.Text.ToString() + "'";
                    cmd.CommandText = "INSERT INTO katagori (katagori_isim) VALUES (" + parametre_katagori + ");";
                    cmd.Connection = baglanti;
                    baglanti.Open();

                    cmd.ExecuteNonQuery();
                    baglanti.Close();
                    String script = "window.alert('Başarıyla Eklenmiştir');";
                    ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
                }
                else
                {
                    String script = "window.alert('Böyle bir yayın evi bulunmakta!');";
                    ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
                }
            }
            else
            {
                String script = "window.alert('Yanlış değer girdiniz!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
            }
        }

        protected void btn_hakkimizdaGuncelle_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtB_hakkimizda.Text.ToString()))
            {
                SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                SqlCommand cmd = new SqlCommand();
                String parametre_katagori = "'" + txtB_hakkimizda.Text.ToString() + "'";
                cmd.CommandText = "UPDATE sayfa Set syf_hakkımızda = "+parametre_katagori+" Where sayfa_id = 1;";
                cmd.Connection = baglanti;
                baglanti.Open();

                cmd.ExecuteNonQuery();
                baglanti.Close();
                String script = "window.alert('Başarıyla Güncellenmiştir');";
                ClientScript.RegisterStartupScript(this.GetType(), "Dogru Deger", script, true);
            }
            else
            {
                String script = "window.alert('Alan boş olmamalıdır!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
            }
        }

        protected void btn_ekle_urun_Click(object sender, EventArgs e)
        {
            int control = 1;
            String yazar_id = "";
            String yayınEvi_id = "";
            String katagori_id = "";
            String urun_resmi = "";
            
            //Resim kontrolü
            if (FileUpload1.HasFile)
                try
                {
                    if (FileUpload1.PostedFile.ContentType == "image/jpeg")
                    {
                        if (FileUpload1.PostedFile.ContentLength < 102400)
                        {
                            FileUpload1.SaveAs(Server.MapPath("~/") + FileUpload1.FileName);
                            urun_resmi = "~/" + FileUpload1.PostedFile.FileName;
                            
                        }
                        else
                        {
                            control = -1;
                        }
                    }
                    else
                    {
                        control = -1;
                    }

                }
                catch (Exception ex)
                {
                    control = 0;
                }
            else
            {
                control = -1;
            }
            //Yayın evi
            yazar_id = DropDownList_yazar.SelectedValue.ToString();
            yazar_id = db.searchYazar(yazar_id).ToString();
            yayınEvi_id = DropDownList_yayinEvi.SelectedItem.Text.ToString();
            yayınEvi_id = db.searchYayinEvi_id(yayınEvi_id).ToString();
            katagori_id = DropDownList_katagori.SelectedItem.Text.ToString();
            katagori_id = db.searchKatagori_id(katagori_id).ToString();

            if (control == 1)
            {
                if (txtControl1.control_isim(txtb_urunİsmi.Text.ToString()) && txtControl1.control_sayi(txtb_urunFiyat.Text.ToString())
                && txtControl1.control_sayi(txtb_urunStokMiktarı.Text.ToString()) && !String.IsNullOrEmpty(txtb_urunMetni.Text.ToString()))
                {
                    SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                    SqlCommand cmd = new SqlCommand();
                    String parametre_urun_resim = "'"+urun_resmi+"'";
                    String parametre_urun_ismi = "'" + txtb_urunİsmi.Text.ToString() + "'";
                    String parametre_yazar_id = "'" + yazar_id + "'";
                    String parametre_yayinEvi_id = "'" + yayınEvi_id + "'";
                    String parametre_katagori_id = "'" + katagori_id + "'";
                    String parametre_urunFiyat = "'" + txtb_urunFiyat.Text.ToString() + "'";
                    String parametre_urunMetin = "'" + txtb_urunMetni.Text.ToString() + "'";
                    String parametre_urunTıklanma = "'0'";
                    String parametre_urunStok = "'" + txtb_urunStokMiktarı.Text.ToString() + "'";

                    cmd.CommandText = "INSERT INTO ürün (urun_resim, urun_isim, yazar_id, yayin_id, katagori_id," +
                        " urun_fiyat, urun_paragraf, urun_tiklanma, urun_stok) " + "VALUES ("
                        + parametre_urun_resim + ", " + parametre_urun_ismi + ", " + parametre_yazar_id + ", " + parametre_yayinEvi_id + ", " 
                        + parametre_katagori_id + ", " + parametre_urunFiyat + ", " + parametre_urunMetin + ", " + parametre_urunTıklanma + ", "
                        + parametre_urunStok + ");";
                    cmd.Connection = baglanti;
                    baglanti.Open();

                    cmd.ExecuteNonQuery();
                    baglanti.Close();
                    String script = "window.alert('Başarıyla yeni ürün eklenmiştir');";
                    ClientScript.RegisterStartupScript(this.GetType(), "Dogru Deger", script, true);
                }
                else
                {
                    String script = "window.alert('Yanlış değer girmeyiniz!Boş alan olmamalıdır!');";
                    ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger", script, true);
                }
            }
            else if(control == -1)
            {
                String script = "window.alert('Yanlış Resim Seçtiniz!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger2", script, true);
            }
            
        }

        protected void btn_sil_Click(object sender, EventArgs e)
        {
            if(!String.IsNullOrEmpty(txtb_silinecek_id.Text.ToString()))
            {
                SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                SqlCommand cmd = new SqlCommand();
                String parametre_urun_id = "'" + txtb_silinecek_id.Text.ToString() + "'";
                cmd.CommandText = "DELETE FROM ürün WHERE urun_id="+ parametre_urun_id+ ";";
                cmd.Connection = baglanti;
                baglanti.Open();
                cmd.ExecuteNonQuery();
                Response.Redirect("admin.aspx");
            } 
            else
            {
                String script = "window.alert('Boş bırakmıyınız!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Yanlıs Deger2", script, true);
            }

        }

        protected void btn_cıkıs_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("default.aspx");
        }
    }
}
