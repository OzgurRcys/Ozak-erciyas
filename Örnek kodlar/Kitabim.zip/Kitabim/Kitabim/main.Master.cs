﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            object kullanici = Session["kullanici_Id"];
            if(kullanici != null)
            {
                pnl_girisYap.Visible = false;
                pnl_hesabim.Visible = true;
                HyperLink1.NavigateUrl = "sepet.aspx";
            }
            else
            {
                pnl_girisYap.Visible = true;
                pnl_hesabim.Visible = false;
            }
        }
    }
}