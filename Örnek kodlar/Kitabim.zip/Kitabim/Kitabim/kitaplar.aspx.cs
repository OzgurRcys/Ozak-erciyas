﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class kitaplar : System.Web.UI.Page
    {
        KitabimEntities database = new KitabimEntities();
        List<ürün> urunler = new List<ürün>();
        List<katagori> katagoriler = new List<katagori>();
        dbOperations db = new dbOperations();

        public List<ürün> edebiyat = new List<ürün>();
        public List<List<ürün>> edebiyat_source = new List<List<ürün>>();
        public List<ürün> tarih = new List<ürün>();
        public List<List<ürün>> tarih_source = new List<List<ürün>>();
        List<ürün> ekonomi = new List<ürün>();
        List<ürün> hukuk = new List<ürün>();
        List<ürün> dergi = new List<ürün>();
        List<ürün> bilgisayar = new List<ürün>();
        List<ürün> cocukKitapları = new List<ürün>();
        List<ürün> din = new List<ürün>();
        List<ürün> egitim = new List<ürün>();
        List<ürün> psikoloji = new List<ürün>();
        List<ürün> spor = new List<ürün>();

        protected void Page_Load(object sender, EventArgs e)
        {
            setUrunler_setKatagoriler();
            setKatagorikList();
            Repeater2.DataSource = edebiyat;
            Repeater2.DataBind();
        }

        protected void btn_filtre_Click(object sender, EventArgs e)
        {
            if(RadioButton1.Checked)
            {
                Repeater2.DataSource = edebiyat;
                Repeater2.DataBind();
            }
            else if(RadioButton2.Checked)
            {
                Repeater2.DataSource = tarih;
                Repeater2.DataBind();
            }
            else if (RadioButton3.Checked)
            {
                Repeater2.DataSource = ekonomi;
                Repeater2.DataBind();
            }
            else if (RadioButton4.Checked)
            {
                Repeater2.DataSource = hukuk;
                Repeater2.DataBind();
            }
            else if (RadioButton5.Checked)
            {
                Repeater2.DataSource = dergi;
                Repeater2.DataBind();
            }
            else if (RadioButton6.Checked)
            {
                Repeater2.DataSource = bilgisayar;
                Repeater2.DataBind();
            }
            else if (RadioButton7.Checked)
            {
                Repeater2.DataSource = cocukKitapları;
                Repeater2.DataBind();
            }
            else if (RadioButton8.Checked)
            {
                Repeater2.DataSource = din;
                Repeater2.DataBind();
            }
            else if (RadioButton9.Checked)
            {
                Repeater2.DataSource = egitim;
                Repeater2.DataBind();
            }
            else if (RadioButton10.Checked)
            {
                Repeater2.DataSource = psikoloji;
                Repeater2.DataBind();
            }
            else if (RadioButton11.Checked)
            {
                Repeater2.DataSource = spor;
                Repeater2.DataBind();
            }

        }
        protected void rptOgrenciler_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            ürün urun = (ürün)e.Item.DataItem;
            Label Label4 = (Label)e.Item.FindControl("Label4");
            Label Label5 = (Label)e.Item.FindControl("Label5");
            Label4.Text = urun.urun_isim;
            Label5.Text = urun.urun_fiyat.ToString();
        }


        public void setUrunler_setKatagoriler()
        {
            urunler = database.ürün.ToList();
            katagoriler = database.katagori.ToList();
        }
        public void setKatagorikList()
        {
            setUrunler_setKatagoriler();
            for(int i = 0; i < urunler.Count; i++)
            {
                if(urunler[i].katagori_id == katagoriler[0].katagori_id)
                {
                    if(edebiyat.Count < 5)
                    {
                        edebiyat.Add(urunler[i]);
                    }
                    else if(edebiyat.Count == 5)
                    {
                        edebiyat_source.Add(edebiyat);
                        edebiyat.RemoveAt(0);
                        edebiyat.RemoveAt(1);
                        edebiyat.RemoveAt(2);
                        edebiyat.RemoveAt(3);
                        edebiyat.RemoveAt(4);
                    }
                    
                }
                else if (urunler[i].katagori_id == katagoriler[1].katagori_id)
                {
                    if (tarih.Count < 5)
                    {
                        tarih.Add(urunler[i]);
                    }
                    else if (tarih.Count == 5)
                    {
                        tarih_source.Add(tarih);
                        tarih.RemoveAt(0);
                        tarih.RemoveAt(1);
                        tarih.RemoveAt(2);
                        tarih.RemoveAt(3);
                        tarih.RemoveAt(4);
                    }
                }
                else if (urunler[i].katagori_id == katagoriler[2].katagori_id)
                {
                    ekonomi.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[3].katagori_id)
                {
                    hukuk.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[4].katagori_id)
                {
                    dergi.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[5].katagori_id)
                {
                    bilgisayar.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[6].katagori_id)
                {
                    cocukKitapları.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[7].katagori_id)
                {
                    din.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[8].katagori_id)
                {
                    egitim.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[9].katagori_id)
                {
                    psikoloji.Add(urunler[i]);
                }
                else if (urunler[i].katagori_id == katagoriler[10].katagori_id)
                {
                    spor.Add(urunler[i]);
                }

                if(i == urunler.Count -1)
                {
                    if(edebiyat.Count != 0)
                    {
                        edebiyat_source.Add(edebiyat);
                    }
                    if (tarih.Count != 0)
                    {
                        tarih_source.Add(tarih);
                    }
                    
                }
            }
        }
        /*
        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //ürün urun = (ürün)e.Item.DataItem;
            //List<List<ürün>> edebiyat_source = (List<List<ürün>>)e.Item.DataItem;
            List<ürün> edebiyat_source = (List<ürün>)e.Item.DataItem;
            Label lbl_baslık_1 = (Label)e.Item.FindControl("lbl_baslık_1");
            Label lbl_baslık_2 = (Label)e.Item.FindControl("lbl_baslık_2");
            Label lbl_baslık_3 = (Label)e.Item.FindControl("lbl_baslık_3");
            Label lbl_baslık_4 = (Label)e.Item.FindControl("lbl_baslık_4");
            Label lbl_baslık_5 = (Label)e.Item.FindControl("lbl_baslık_5");

            Label lbl_fiyat_1 = (Label)e.Item.FindControl("lbl_fiyat_1");
            Label lbl_fiyat_2 = (Label)e.Item.FindControl("lbl_fiyat_2");
            Label lbl_fiyat_3 = (Label)e.Item.FindControl("lbl_fiyat_3");
            Label lbl_fiyat_4 = (Label)e.Item.FindControl("lbl_fiyat_4");
            Label lbl_fiyat_5 = (Label)e.Item.FindControl("lbl_fiyat_5");

            Image img1 = (Image)e.Item.FindControl("img1");
            Image img2 = (Image)e.Item.FindControl("img2");
            Image img3 = (Image)e.Item.FindControl("img3");
            Image img4 = (Image)e.Item.FindControl("img4");
            Image img5 = (Image)e.Item.FindControl("img5");

            Label lbl_yazar_1 = (Label)e.Item.FindControl("lbl_yazar_1");
            Label lbl_yazar_2 = (Label)e.Item.FindControl("lbl_yazar_2");
            Label lbl_yazar_3 = (Label)e.Item.FindControl("lbl_yazar_3");
            Label lbl_yazar_4 = (Label)e.Item.FindControl("lbl_yazar_4");
            Label lbl_yazar_5 = (Label)e.Item.FindControl("lbl_yazar_5");
            String yazarIsim = "";

            Panel pnl1 = (Panel)e.Item.FindControl("pnl1");
            Panel pnl2 = (Panel)e.Item.FindControl("pnl2");
            Panel pnl3 = (Panel)e.Item.FindControl("pnl3");
            Panel pnl4 = (Panel)e.Item.FindControl("pnl4");
            Panel pnl5 = (Panel)e.Item.FindControl("pnl5");

            HyperLink link_1 = (HyperLink)e.Item.FindControl("link_1");
            HyperLink link_2 = (HyperLink)e.Item.FindControl("link_2");
            HyperLink link_3 = (HyperLink)e.Item.FindControl("link_3");
            HyperLink link_4 = (HyperLink)e.Item.FindControl("link_4");
            HyperLink link_5 = (HyperLink)e.Item.FindControl("link_5");

            String link = "";
            if (edebiyat_source.Count < 1)
            {
                //Panel Kapatma
                pnl1.Visible = false;
                pnl2.Visible = false;
                pnl3.Visible = false;
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------

            }
            else if (edebiyat_source.Count < 2)
            {
                //Panel Kapatma
                pnl2.Visible = false;
                pnl3.Visible = false;
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
            }
            else if (edebiyat_source.Count < 3)
            {
                //Panel Kapatma
                pnl3.Visible = false;
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
            }
            else if (edebiyat_source.Count < 4)
            {
                //Panel Kapatma
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                lbl_baslık_3.Text = edebiyat_source[2].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                lbl_fiyat_3.Text = edebiyat_source[2].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                img3.ImageUrl = edebiyat_source[2].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[2].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[2].yazar_id).yazar_soyisim;
                lbl_yazar_3.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[2].urun_id;
                link_3.NavigateUrl = link;
            }
            else if (edebiyat_source.Count < 5)
            {
                //Panel Kapatma
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                lbl_baslık_3.Text = edebiyat_source[2].urun_isim;
                lbl_baslık_4.Text = edebiyat_source[3].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                lbl_fiyat_3.Text = edebiyat_source[2].urun_fiyat.ToString() + " TL";
                lbl_fiyat_4.Text = edebiyat_source[3].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                img3.ImageUrl = edebiyat_source[2].urun_resim;
                img4.ImageUrl = edebiyat_source[3].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[2].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[2].yazar_id).yazar_soyisim;
                lbl_yazar_3.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[3].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[3].yazar_id).yazar_soyisim;
                lbl_yazar_4.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[2].urun_id;
                link_3.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[3].urun_id;
                link_4.NavigateUrl = link;
            }
            else if(edebiyat_source.Count < 6)
            {
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                lbl_baslık_3.Text = edebiyat_source[2].urun_isim;
                lbl_baslık_4.Text = edebiyat_source[3].urun_isim;
                lbl_baslık_5.Text = edebiyat_source[4].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                lbl_fiyat_3.Text = edebiyat_source[2].urun_fiyat.ToString() + " TL";
                lbl_fiyat_4.Text = edebiyat_source[3].urun_fiyat.ToString() + " TL";
                lbl_fiyat_5.Text = edebiyat_source[4].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                img3.ImageUrl = edebiyat_source[2].urun_resim;
                img4.ImageUrl = edebiyat_source[3].urun_resim;
                img5.ImageUrl = edebiyat_source[4].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim +" "+ db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[2].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[2].yazar_id).yazar_soyisim;
                lbl_yazar_3.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[3].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[3].yazar_id).yazar_soyisim;
                lbl_yazar_4.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[4].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[4].yazar_id).yazar_soyisim;
                lbl_yazar_5.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[2].urun_id;
                link_3.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[3].urun_id;
                link_4.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[4].urun_id;
                link_5.NavigateUrl = link;
            }

        }
        */
        protected void Repeater2_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            ürün a = (ürün)e.Item.DataItem;
            //int i = 1;
            Label lbl_siraNumarasi = (Label)e.Item.FindControl("lbl_siraNumarasi");
            Label lbl_baslık_1 = (Label)e.Item.FindControl("lbl_baslık_1");
            Label lbl_fiyat_1 = (Label)e.Item.FindControl("lbl_fiyat_1");
            Image img1 = (Image)e.Item.FindControl("img1");
            Label lbl_yazar_1 = (Label)e.Item.FindControl("lbl_yazar_1");
            HyperLink link = (HyperLink)e.Item.FindControl("link");
            String yazarIsim = "";
            String yayinIsim = "";
            yazarIsim = db.searchYazar(a.yazar_id).yazar_isim + " " + db.searchYazar(a.yazar_id).yazar_soyisim;
            yayinIsim = db.searchYayin(a.yayin_id).yayin_evi;

            lbl_baslık_1.Text = a.urun_isim.ToString();
            lbl_fiyat_1.Text = a.urun_fiyat.ToString() + " TL";
            img1.ImageUrl = a.urun_resim.ToString();
            lbl_yazar_1.Text = yazarIsim + " | " + yayinIsim;
            String linkS = "kitapBilgisi.aspx?kitap_id=" + a.urun_id.ToString();
            link.NavigateUrl = linkS;
            //lbl_siraNumarasi.Text = i.ToString();
            //i++;
        }
    }
}