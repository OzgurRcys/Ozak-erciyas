﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class kitapBilgisi : System.Web.UI.Page
    {
        public KitabimEntities database = new KitabimEntities();
        public dbOperations db = new dbOperations();
        string id = "";
        public sepet sepet1;
        protected void Page_Load(object sender, EventArgs e)
        {
            id = Request.QueryString["kitap_id"];
            ürün urun1 = new ürün();
            urun1 = db.searchUrun(Int32.Parse(id));
            yazar yazar1 = new yazar();
            yazar1 = db.searchYazar(urun1.yazar_id);
            yayinEvi yayinEvi1 = new yayinEvi();
            yayinEvi1 = db.searchYayin(urun1.yayin_id);

            String yazar_yazyın = yazar1.yazar_isim+" "+yazar1.yazar_soyisim+" | "+yayinEvi1.yayin_evi;
            lbl_baslik.Text = urun1.urun_isim;
            lbl_aciklama.Text = urun1.urun_paragraf;
            lbl_fiyat.Text = urun1.urun_fiyat.ToString() + " TL";
            lbl_yazar_yayin.Text = yazar_yazyın;
            img1.ImageUrl = urun1.urun_resim;

        }

        protected void btn_sepeteEkle_Click(object sender, EventArgs e)
        {
            

            object kullanici = Session["kullanici_Id"];
            if (kullanici != null)
            {
                int urun_id = 0;
                int kln_id = 0;
                kln_id = (int)Session["kullanici_Id"];
                urun_id = Int32.Parse(id);
                SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                SqlCommand cmd = new SqlCommand();
                //SqlDataReader dr;
                
                cmd.CommandText = "INSERT INTO sepet (kullanici_Id, urun_id) VALUES (@kln_id, @urun_id);";
                cmd.Parameters.Add("@kln_id", SqlDbType.Int);
                cmd.Parameters["@kln_id"].Value = kln_id;
                cmd.Parameters.Add("@urun_id", SqlDbType.Int);
                cmd.Parameters["@urun_id"].Value = urun_id;
                cmd.Connection = baglanti;
                baglanti.Open();
                cmd.ExecuteNonQuery();

                baglanti.Close();
                String script = "window.alert('Sepete eklenmiştir!');";
                ClientScript.RegisterStartupScript(this.GetType(), "sepetEkleme", script, true);
                //Response.Redirect("kitaplar.aspx");
                /*
                int urun_id = 0;
                int kln_id = 0;
                sepet sepetEkle = new sepet();
                kln_id = (int)Session["kullanici_Id"];
                urun_id = Int32.Parse(id);
                kayitOl kayitOl = new kayitOl();
                sepetEkle.urun_id = urun_id;
                sepetEkle.kullanici_Id = kln_id;
                //kayitOl.database.sepet.Add(sepetEkle);
                //kayitOl.database.SaveChanges();
                //database.sepet.Add(sepetEkle);
                //database.SaveChanges();*/
            }
            else
            {
                String script = "window.alert('Kullanıcı Girişi Yapmanız Gerekmektedir!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Hata_kullanıcı_girişi", script, true);
            }
            
        }
    }
}