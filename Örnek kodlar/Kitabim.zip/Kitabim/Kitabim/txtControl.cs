﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;

namespace Kitabim
{
    public class txtControl
    {
        public bool control_sayi(String fiyat)
        {
            bool sonuc = true;
            for (int i = 0; i < fiyat.Length; i++)
            {
                if (!char.IsDigit(fiyat[i]))
                {
                    sonuc = false;
                }
            }
            return sonuc;
        }
        public bool control_isim(String isim)
        {
            bool sonuc = false;
            bool digit = true;
            isim = isim.Trim();
            for (int i = 0; i < isim.Length; i++)
                if (char.IsDigit(isim[i]))
                {
                    digit = false;
                }
                    
            if (isim.Count() > 2 && isim.Count() < 11 && digit == true)
            {
                sonuc = true;
            }
            return sonuc;
        }
        public static bool control_telefon(string telefon)
        {
            string RegexDesen = @"^(05(\d{9}))$";
            Match Eslesme = Regex.Match(telefon, RegexDesen, RegexOptions.IgnoreCase);
            return Eslesme.Success; // bool değer döner
        }

        public bool control_email(string emailAddress)
        {
            string patternStrict = @"^(([^<>()[\]\\.,;:\s@\""]+"
            + @"(\.[^<>()[\]\\.,;:\s@\""]+)*)|(\"".+\""))@"
            + @"((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
            + @"\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+"
            + @"[a-zA-Z]{2,}))$";
            Regex reStrict = new Regex(patternStrict);
            bool isStrictMatch = reStrict.IsMatch(emailAddress);
            return isStrictMatch;

        }

        public bool control_kullaniciAdi(String isim)
        {
            bool sonuc = false;
            isim = isim.Trim();
            if (isim.Count() > 2 && isim.Count() < 11)
            {
                sonuc = true;
            }
            return sonuc;
        }

        public bool controlSifre2(String sifre1,String sifre2)
        {
            bool sonuc = false;
            int deger = String.Compare(sifre2, sifre1);
            if(deger == 0)
            {
                sonuc=true;
            }
            return sonuc;
        }

        public bool controlBosluk(String isim, String soyisim, String kullaniciAdi, String sifre, String ePosta, String telefon, String sifre2)
        {
            bool sonuc = false;
            if (!String.IsNullOrWhiteSpace(isim) && 
                !String.IsNullOrWhiteSpace(soyisim) &&
                !String.IsNullOrWhiteSpace(kullaniciAdi) &&
                !String.IsNullOrWhiteSpace(sifre) &&
                !String.IsNullOrWhiteSpace(ePosta) &&
                !String.IsNullOrWhiteSpace(telefon) &&
                !String.IsNullOrWhiteSpace(sifre2)
                )
            {
                sonuc = true;
            }
            return sonuc;
        }


    }
}