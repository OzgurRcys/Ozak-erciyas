﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Kitabim
{
    public class dbOperations
    {
        KitabimEntities database = new KitabimEntities();
        txtControl txtControl = new txtControl();
        public List<kullanici> kullanici_list = new List<kullanici>();

        public List<iletisim> iletisim_list = new List<iletisim>();
        public List<cinsiyet> cinsiyet_list = new List<cinsiyet>();
        public List<ürün> ürün_list = new List<ürün>();
        public List<katagori> katagori_list = new List<katagori>();
        public List<yayinEvi> yayinEvi_list = new List<yayinEvi>();
        public List<yazar> yazar_list = new List<yazar>();
        public List<sayfa> sayfa_list = new List<sayfa>();

        public int controlKullanici(String nickName,String pass)
        {
            kullanici_list = database.kullanici.ToList();
            int sonuc = 0;
            //sonuc = string.Compare(kullanici_list[0].kln_kullanıciAdi.ToString(), nickName);
            //kullanici_list.Count;

            for (int i = 0; i < kullanici_list.Count; i++)
            {
                int deger1 = string.Compare(kullanici_list[i].kln_kullanıciAdi.ToString(), nickName);
                int deger2 = string.Compare(kullanici_list[i].kln_sifre.ToString() , pass);
                if (deger1 == 0 && deger2 == 0)
                {
                    //&& 
                    sonuc = kullanici_list[i].kullanici_Id;
                    break;
                }    
            }
            return sonuc;
        }

        public bool add_Kullanici(String isim,String soyisim,int cinsiyet,String kullaniciAdi, String sifre,String ePosta,String telefon,String sifre2)
        {
            bool sonuc = false;
            if(
                txtControl.control_isim(isim) &&
                txtControl.control_isim(soyisim) &&
                txtControl.control_kullaniciAdi(kullaniciAdi) &&
                txtControl.control_kullaniciAdi(sifre) &&
                txtControl.control_email(ePosta) &&
                txtControl.control_telefon(telefon) &&
                txtControl.controlSifre2(sifre,sifre2)
            )
            {
                sonuc=true;
            }
            

            return sonuc;
        }

        public bool control_emailAndtelefon(String email,String telefon)
        {
            bool sonuc = true;
            iletisim_list = database.iletisim.ToList();
            for(int i=0;i<iletisim_list.Count;i++)
            {
                if(iletisim_list[i].iletisim_ePosta.Equals(email) )
                {
                    sonuc = false;
                }
                if (iletisim_list[i].iletisim_telefon.Equals(telefon))
                {
                    sonuc = false;
                }
            }
            return sonuc;
        }

        public bool control_kullaniciAdi(String kullaniciAdi)
        {
            bool sonuc = true;
            kullaniciAdi = kullaniciAdi.Trim();
            kullanici_list = database.kullanici.ToList();
            for (int i = 0; i < kullanici_list.Count; i++)
            {
                if (kullanici_list[i].kln_kullanıciAdi.Equals(kullaniciAdi))
                {
                    sonuc = false;
                }
            }
            return sonuc;
        }

        public kullanici searchKullanici(int id)
        {
            kullanici sonuc = new kullanici();
            kullanici_list = database.kullanici.ToList();
            for(int i = 0; i < kullanici_list.Count; i++)
            {
                if(kullanici_list[i].kullanici_Id == id)
                {
                    sonuc.kln_isim = kullanici_list[i].kln_isim;
                    sonuc.iletisim_id = kullanici_list[i].iletisim_id;
                    sonuc.kln_soyIsim = kullanici_list[i].kln_soyIsim;
                    sonuc.cinsiyet_id = kullanici_list[i].cinsiyet_id;
                }
            }
            return sonuc;
        }
        public iletisim searchİletisim(int iletisim_id)
        {
            iletisim sonuc = new iletisim();
            iletisim_list = database.iletisim.ToList();
            for (int i = 0; i < iletisim_list.Count; i++)
            {
                if (iletisim_list[i].iletisim_id == iletisim_id)
                {
                    sonuc.iletisim_telefon = iletisim_list[i].iletisim_telefon;
                    sonuc.iletisim_ePosta = iletisim_list[i].iletisim_ePosta;
                }
            }
            return sonuc;
        }

        public yazar searchYazar(int yazar_id)
        {
            yazar sonuc = new yazar();
            yazar_list = database.yazar.ToList();
            for (int i = 0; i < yazar_list.Count; i++)
            {
                if (yazar_list[i].yazar_id == yazar_id)
                {
                    sonuc.yazar_isim = yazar_list[i].yazar_isim;
                    sonuc.yazar_soyisim = yazar_list[i].yazar_soyisim;
                }
            }
            return sonuc;
        }
        public yayinEvi searchYayin(int yayin_id)
        {
            yayinEvi sonuc = new yayinEvi();
            yayinEvi_list = database.yayinEvi.ToList();
            for (int i = 0; i < yayinEvi_list.Count; i++)
            {
                if (yayinEvi_list[i].yayin_id == yayin_id)
                {
                    sonuc.yayin_evi = yayinEvi_list[i].yayin_evi;
                }
            }
            return sonuc;
        }

        public ürün searchUrun(int urun_id)
        {
            ürün sonuc = new ürün();
            ürün_list = database.ürün.ToList();
            for (int i = 0; i < ürün_list.Count; i++)
            {
                if (ürün_list[i].urun_id == urun_id)
                {
                    sonuc.urun_isim = ürün_list[i].urun_isim;
                    sonuc.urun_resim = ürün_list[i].urun_resim;
                    sonuc.urun_fiyat = ürün_list[i].urun_fiyat;
                    sonuc.urun_paragraf = ürün_list[i].urun_paragraf;
                    sonuc.yazar_id = ürün_list[i].yazar_id;
                    sonuc.yayin_id = ürün_list[i].yayin_id;
                    sonuc.urun_stok = ürün_list[i].urun_stok;
                    sonuc.urun_tiklanma = ürün_list[i].urun_tiklanma;
                }
            }
            return sonuc;
        }

        public int searchYayinEvi_id(String yayinEvi)
        {
            int sonuc = 0;
            yayinEvi_list = database.yayinEvi.ToList();
            for(int i = 0; i < yayinEvi_list.Count; i++)
            {
                if(yayinEvi_list[i].yayin_evi.Equals(yayinEvi))
                {
                    sonuc = yayinEvi_list[i].yayin_id;
                }
            }
            return sonuc;
        }
        public String searchKatagori_id(String katagori_id)
        {
            string sonuc = "";
            katagori_list = database.katagori.ToList();
            for (int i = 0; i < katagori_list.Count; i++)
            {
                if (katagori_list[i].katagori_isim.Equals(katagori_id))
                {
                    sonuc = katagori_list[i].katagori_id.ToString();
                }
            }
            return sonuc;
        }
        public String searchYazar(String yazar_id)
        {
            string sonuc = "";
            yazar_list = database.yazar.ToList();
            for (int i = 0; i < yazar_list.Count; i++)
            {
                String a = yazar_list[i].yazar_isim.ToString() +" "+yazar_list[i].yazar_soyisim.ToString();
                if (a.Equals(yazar_id))
                {
                    sonuc = yazar_list[i].yazar_id.ToString();
                }
            }
            return sonuc;
        }

    }
}