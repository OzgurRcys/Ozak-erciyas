﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class kayitOl : System.Web.UI.Page
    {
        dbOperations db = new dbOperations();
        public KitabimEntities database = new KitabimEntities();
        txtControl txtControl = new txtControl();
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btn_geriDon_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx");
        }

        protected void btn_kayitOl_Click(object sender, EventArgs e)
        {
            String isim = txt_isim.Text;
            String soyisim = txt_soyisim.Text;
            String kullaniciAdi = txt_kullaniciAdi.Text;
            String sifre1 = txt_sifre.Text;
            String sifre2 = txt_sifre2.Text;
            int cinsiyet = 0;
            String email = txt_email.Text;
            String telefon = txt_telefon.Text;
            if(radioBtn_Erkek.Checked)
            {
                cinsiyet = 3;
            }
            else if(radioBtn_Kadın.Checked)
            {
                cinsiyet = 4;
            }
            if (txtControl.controlBosluk(
                isim,
                soyisim,
                kullaniciAdi,
                sifre1,
                email,
                telefon,
                sifre2
                ))
            {
                if (db.control_emailAndtelefon(email, telefon) && db.add_Kullanici(
                isim,
                soyisim,
                cinsiyet,
                kullaniciAdi,
                sifre1,
                email,
                telefon,
                sifre2
                ) && db.control_kullaniciAdi(kullaniciAdi))
                {
                    iletisim i1 = new iletisim();
                    i1.iletisim_ePosta = email;
                    i1.iletisim_telefon = telefon;
                    database.iletisim.Add(i1);
                    database.SaveChanges();
                    List<iletisim> list = new List<iletisim>();
                    list = database.iletisim.ToList();
                    int iletisim_id = list[list.Count - 1].iletisim_id;
                    kullanici k1 = new kullanici();
                    k1.kln_isim = isim;
                    k1.kln_soyIsim = soyisim;
                    k1.kln_sifre = sifre1;
                    k1.kln_kullanıciAdi = kullaniciAdi;
                    k1.cinsiyet_id = cinsiyet;
                    k1.iletisim_id = iletisim_id;
                    database.kullanici.Add(k1);
                    database.SaveChanges();

                    List<kullanici> list2 = new List<kullanici>();
                    list2 = database.kullanici.ToList();
                    int kullanici_id = list2[list2.Count - 1].kullanici_Id;

                    Session.Timeout = 300;
                    Session.Add("kullanici_Id", kullanici_id);
                    Session.Add("kln_ad", isim+" "+soyisim);
                    Session.Add("kln_ePosta", email);
                    Session.Add("kln_telefon", telefon);
                    Session.Add("kln_cinsiyet", cinsiyet);

                    Response.Redirect("default.aspx");

                }
                else
                {
                    lbl_Sonuc.Text = "Hatalı Giriş";
                    //lbl_Sonuc.Text = db.control_emailAndtelefon(email, telefon).ToString();
                    /*lbl_Sonuc.Text = db.add_Kullanici(
                isim,
                soyisim,
                cinsiyet,
                kullaniciAdi,
                sifre1,
                email,
                telefon,
                sifre2
                ).ToString();*/
                    //lbl_Sonuc.Text = db.control_kullaniciAdi(kullaniciAdi).ToString();
                }
            }
            else
            {
                lbl_Sonuc.Text = "Boşlukları Doldurunuz";
            }
            
            
            
        }
    }
}