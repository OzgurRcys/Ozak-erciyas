﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class girisyap : System.Web.UI.Page
    {
        dbOperations dbOpr = new dbOperations();
        KitabimEntities database = new KitabimEntities();
        public List<kullanici> kullanici_list = new List<kullanici>();
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
        }

        protected void btn_girisYap_Click(object sender, EventArgs e)
        {
            String nickName = txtNickName.Text;
            nickName = nickName.Trim();
            String password = txtPass.Text;
            password = password.Trim();
            int sonuc = 0;
            sonuc = dbOpr.controlKullanici(nickName, password);
            if(nickName.Equals("Admin"))
            {
                Response.Redirect("admin.aspx");
            }
            else
            {
                if (sonuc != 0)
                {
                    Session.Timeout = 300;
                    Session.Add("kullanici_Id", sonuc);
                    kullanici oturum = new kullanici();
                    oturum = dbOpr.searchKullanici(sonuc);

                    Session.Add("kln_ad", oturum.kln_isim + " " + oturum.kln_soyIsim);

                    iletisim oturum_iletisim = new iletisim();
                    oturum_iletisim = dbOpr.searchİletisim(oturum.iletisim_id);

                    Session.Add("kln_ePosta", oturum_iletisim.iletisim_ePosta);
                    Session.Add("kln_telefon", oturum_iletisim.iletisim_telefon);


                    Session.Add("kln_cinsiyet", oturum.cinsiyet_id);
                    Response.Redirect("default.aspx");
                    lbl_sonuc.Text = sonuc.ToString();
                }
                else
                {
                    lbl_sonuc.Text = "Yanlış giriş yaptınız!";
                }
            }
            
            
        }

        protected void btn_kayıtOL_Click(object sender, EventArgs e)
        {
            Response.Redirect("kayitOl.aspx");
        }
    }
}