﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class Hakkımızda : System.Web.UI.Page
    {
        KitabimEntities database = new KitabimEntities();
        public List<sayfa> sayfa_list = new List<sayfa>();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            sayfa_list = database.sayfa.ToList();
            lbl_hakkimizda.Text = sayfa_list[0].syf_hakkımızda;
        }
    }
}