﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class sepet : System.Web.UI.Page
    {
        KitabimEntities dataBase = new KitabimEntities();
        List<sepet> sepetList = new List<sepet>();
        List<int> urun_idList = new List<int>();
        List<ürün> urunList = new List<ürün>();
        List<ürün> db_urunList = new List<ürün>();
        dbOperations db = new dbOperations();
        List<ürün> toplam = new List<ürün>();
        protected void Page_Load(object sender, EventArgs e)
        {
            setUrun_id();
            Repeater1.DataSource = urunList;
            Repeater1.DataBind();
            toplamFiyat();
            String script = "";

        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            ürün a = (ürün)e.Item.DataItem;
            //int i = 1;
            //Label lbl_siraNumarasi = (Label)e.Item.FindControl("lbl_siraNumarasi");
            Label lbl_baslık_1 = (Label)e.Item.FindControl("lbl_baslık_1");
            Label lbl_fiyat_1 = (Label)e.Item.FindControl("lbl_fiyat_1");
            Image img1 = (Image)e.Item.FindControl("img1");
            Label lbl_yazar_1 = (Label)e.Item.FindControl("lbl_yazar_1");
            Label lbl_sira = (Label)e.Item.FindControl("lbl_sira");
            String yazarIsim = "";
            String yayinIsim = "";
            yazarIsim = db.searchYazar(a.yazar_id).yazar_isim + " " + db.searchYazar(a.yazar_id).yazar_soyisim;
            yayinIsim = db.searchYayin(a.yayin_id).yayin_evi;

            lbl_baslık_1.Text = a.urun_isim.ToString();
            lbl_fiyat_1.Text = a.urun_fiyat.ToString() + " TL";
            img1.ImageUrl = a.urun_resim.ToString();
            lbl_yazar_1.Text = yazarIsim + " | " + yayinIsim;
            toplam.Add(a);
            lbl_sira.Text = toplam.Count.ToString();
            //lbl_siraNumarasi.Text = i.ToString();
            //i++;
        }
        public void toplamFiyat()
        {
            int sonuc = 0;
            for (int i = 0; i < toplam.Count; i++)
            {
                sonuc = sonuc + toplam[i].urun_fiyat;
            }
            lbl_toplam.Text = "Toplam Fiyat: " + sonuc.ToString() + " TL";
        }
        public void setUrun_id()
        {
            String kullanici_id = Session["kullanici_Id"].ToString();
            sepetList = dataBase.sepet.ToList();
            for (int i = 0; i < sepetList.Count; i++)
            {
                if (sepetList[i].kullanici_Id.ToString().Equals(kullanici_id))
                {
                    urun_idList.Add((int)sepetList[i].urun_id);
                }
            }
            db_urunList = dataBase.ürün.ToList();
            for (int i = 0; i < db_urunList.Count; i++)
            {
                for (int j = 0; j < urun_idList.Count; j++)
                {
                    if (db_urunList[i].urun_id == urun_idList[j])
                    {
                        urunList.Add(db_urunList[i]);
                    }
                }
            }
        }

        protected void btn_sil_Click(object sender, EventArgs e)
        {
            int i = 0;
            i = i + 5;

            String index = txt_sil.Text.Trim();
            int index_int = Int32.Parse(index);
            int silinecekUrun_id = 0;
            String kullanici_idSSS = Session["kullanici_Id"].ToString();
            int kullanici_id = Int32.Parse(kullanici_idSSS);
            if (index_int <= urunList.Count)
            {
                silinecekUrun_id = urunList[index_int - 1].urun_id;
                SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "DELETE FROM sepet WHERE kullanici_Id=@kln_id AND urun_id=@urun_id;";
                cmd.Parameters.Add("@kln_id", SqlDbType.Int);
                cmd.Parameters["@kln_id"].Value = kullanici_id;
                cmd.Parameters.Add("@urun_id", SqlDbType.Int);
                cmd.Parameters["@urun_id"].Value = silinecekUrun_id;
                cmd.Connection = baglanti;
                baglanti.Open();
                cmd.ExecuteNonQuery();

                baglanti.Close();
                Response.Redirect("sepet.aspx");
            }
            else
            {
                String script = "window.alert('Yanlış değer girdiniz!');";
                ClientScript.RegisterStartupScript(this.GetType(), "Hata_kullanıcı_girişi", script, true);
            }
        }

        protected void btn_sepetOnayla_Click(object sender, EventArgs e)
        {
            
            SqlConnection baglanti2 = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
            SqlCommand cmd2 = new SqlCommand();
            String kullanici_idString = Session["kullanici_Id"].ToString();
            int kullanici_id2 = Int32.Parse(kullanici_idString);
            kullanici_idString = "'"+kullanici_idString+"'";
            
            String parametre1_kln_id ="";
            String parametre2_urun_id= "";
            for (int i = 0; i < urunList.Count; i++)
            {
                parametre1_kln_id = "@kln_id" + (i + 2);
                parametre2_urun_id = "@urun_id" + (i + 2);
                String urun_id_String = "'"+urunList[i].urun_id.ToString()+"'";
                cmd2.CommandText = "INSERT INTO eskiSiparis (kullanici_Id, urun_id) VALUES ("+kullanici_idString+", "+ urun_id_String + ");";
                cmd2.Connection = baglanti2;
                baglanti2.Open();
                
                cmd2.ExecuteNonQuery();
                baglanti2.Close();



            }
            SqlConnection baglanti3 = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["Veritabani"].ConnectionString);
            SqlCommand cmd3 = new SqlCommand();
            cmd3.CommandText = "DELETE FROM sepet WHERE kullanici_Id=@kln_id3";
            cmd3.Parameters.Add("@kln_id3", SqlDbType.Int);
            cmd3.Parameters["@kln_id3"].Value = kullanici_id2;
            cmd3.Connection = baglanti3;
            baglanti3.Open();
            cmd3.ExecuteNonQuery();

            baglanti3.Close();

            
            
            Response.Redirect("sepet.aspx");
            

        }
        
    }
}