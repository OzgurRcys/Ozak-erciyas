﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class profilim : System.Web.UI.Page
    {
        KitabimEntities dataBase = new KitabimEntities();
        List<eskiSiparis> eskiSiparisList = new List<eskiSiparis>();
        List<int> urun_idList = new List<int>();
        List<ürün> urunList = new List<ürün>();
        List<ürün> db_urunList = new List<ürün>();
        dbOperations db = new dbOperations();
        protected void Page_Load(object sender, EventArgs e)
        {
            lbl_isim.Text = Session["kln_ad"].ToString();
            String ePosta = Session["kln_ePosta"].ToString();
            lbl_mail.Text = ePosta;
            String telefon = Session["kln_telefon"].ToString();
            lbl_telefon.Text = telefon;
            String cinsiyet = Session["kln_cinsiyet"].ToString();
            int cinsiyet_id = Int32.Parse(cinsiyet);
            if (cinsiyet_id == 3)
            {
                img_profil.ImageUrl = "~/images/erkek.png";
            }
            else if (cinsiyet_id == 4)
            {
                img_profil.ImageUrl = "~/images/kadın.png";
            }
            //setSourceList();
            setUrun_id();
            Repeater1.DataSource = urunList;
            Repeater1.DataBind();

        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            ürün a = (ürün)e.Item.DataItem;
            //int i = 1;
            Label lbl_siraNumarasi = (Label)e.Item.FindControl("lbl_siraNumarasi");
            Label lbl_baslık_1 = (Label)e.Item.FindControl("lbl_baslık_1");
            Label lbl_fiyat_1 = (Label)e.Item.FindControl("lbl_fiyat_1");
            Image img1 = (Image)e.Item.FindControl("img1");
            Label lbl_yazar_1 = (Label)e.Item.FindControl("lbl_yazar_1");
            String yazarIsim = "";
            String yayinIsim = "";
            yazarIsim = db.searchYazar(a.yazar_id).yazar_isim + " " + db.searchYazar(a.yazar_id).yazar_soyisim;
            yayinIsim = db.searchYayin(a.yayin_id).yayin_evi;

            lbl_baslık_1.Text = a.urun_isim.ToString();
            lbl_fiyat_1.Text = a.urun_fiyat.ToString() + " TL";
            img1.ImageUrl = a.urun_resim.ToString();
            lbl_yazar_1.Text = yazarIsim +" | "+yayinIsim;
            //lbl_siraNumarasi.Text = i.ToString();
            //i++;
        }

        public void setUrun_id()
        {
            String kullanici_id = Session["kullanici_Id"].ToString();
            eskiSiparisList = dataBase.eskiSiparis.ToList();
            for (int i = 0; i < eskiSiparisList.Count; i++)
            {
                if (eskiSiparisList[i].kullanici_Id.ToString().Equals(kullanici_id))
                {
                    urun_idList.Add(eskiSiparisList[i].urun_id);
                }
            }
            db_urunList = dataBase.ürün.ToList();
            for(int i = 0; i < db_urunList.Count; i++)
            {
                for(int j = 0; j<urun_idList.Count; j++)
                {
                    if (db_urunList[i].urun_id == urun_idList[j])
                    {
                        urunList.Add(db_urunList[i]);
                    }
                }
            }
        }

        protected void btn_cikis_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("default.aspx");
        }
    }
}