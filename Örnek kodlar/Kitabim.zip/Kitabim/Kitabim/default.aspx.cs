﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Kitabim
{
    public partial class _default : System.Web.UI.Page
    {
        public KitabimEntities database = new KitabimEntities();
        public List<ürün> urunler = new List<ürün>();
        public List<ürün> urunler2 = new List<ürün>();
        public List<katagori> katagoriler = new List<katagori>();
        public dbOperations db = new dbOperations();
        public List<List<ürün>> urunler_source = new List<List<ürün>>();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            setSourceList();
            
            Repeater2.DataSource = urunler;
            Repeater2.DataBind();
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //ürün urun = (ürün)e.Item.DataItem;
            //List<List<ürün>> edebiyat_source = (List<List<ürün>>)e.Item.DataItem;
            List<ürün> edebiyat_source = (List<ürün>)e.Item.DataItem;
            Label lbl_baslık_1 = (Label)e.Item.FindControl("lbl_baslık_1");
            Label lbl_baslık_2 = (Label)e.Item.FindControl("lbl_baslık_2");
            Label lbl_baslık_3 = (Label)e.Item.FindControl("lbl_baslık_3");
            Label lbl_baslık_4 = (Label)e.Item.FindControl("lbl_baslık_4");
            Label lbl_baslık_5 = (Label)e.Item.FindControl("lbl_baslık_5");

            Label lbl_fiyat_1 = (Label)e.Item.FindControl("lbl_fiyat_1");
            Label lbl_fiyat_2 = (Label)e.Item.FindControl("lbl_fiyat_2");
            Label lbl_fiyat_3 = (Label)e.Item.FindControl("lbl_fiyat_3");
            Label lbl_fiyat_4 = (Label)e.Item.FindControl("lbl_fiyat_4");
            Label lbl_fiyat_5 = (Label)e.Item.FindControl("lbl_fiyat_5");

            Image img1 = (Image)e.Item.FindControl("img1");
            Image img2 = (Image)e.Item.FindControl("img2");
            Image img3 = (Image)e.Item.FindControl("img3");
            Image img4 = (Image)e.Item.FindControl("img4");
            Image img5 = (Image)e.Item.FindControl("img5");

            Label lbl_yazar_1 = (Label)e.Item.FindControl("lbl_yazar_1");
            Label lbl_yazar_2 = (Label)e.Item.FindControl("lbl_yazar_2");
            Label lbl_yazar_3 = (Label)e.Item.FindControl("lbl_yazar_3");
            Label lbl_yazar_4 = (Label)e.Item.FindControl("lbl_yazar_4");
            Label lbl_yazar_5 = (Label)e.Item.FindControl("lbl_yazar_5");
            String yazarIsim = "";

            Panel pnl1 = (Panel)e.Item.FindControl("pnl1");
            Panel pnl2 = (Panel)e.Item.FindControl("pnl2");
            Panel pnl3 = (Panel)e.Item.FindControl("pnl3");
            Panel pnl4 = (Panel)e.Item.FindControl("pnl4");
            Panel pnl5 = (Panel)e.Item.FindControl("pnl5");

            HyperLink link_1 = (HyperLink)e.Item.FindControl("link_1");
            HyperLink link_2 = (HyperLink)e.Item.FindControl("link_2");
            HyperLink link_3 = (HyperLink)e.Item.FindControl("link_3");
            HyperLink link_4 = (HyperLink)e.Item.FindControl("link_4");
            HyperLink link_5 = (HyperLink)e.Item.FindControl("link_5");

            String link = "";
            if (edebiyat_source.Count < 1)
            {
                //Panel Kapatma
                pnl1.Visible = false;
                pnl2.Visible = false;
                pnl3.Visible = false;
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------

            }
            else if (edebiyat_source.Count < 2)
            {
                //Panel Kapatma
                pnl2.Visible = false;
                pnl3.Visible = false;
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
            }
            else if (edebiyat_source.Count < 3)
            {
                //Panel Kapatma
                pnl3.Visible = false;
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
            }
            else if (edebiyat_source.Count < 4)
            {
                //Panel Kapatma
                pnl4.Visible = false;
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                lbl_baslık_3.Text = edebiyat_source[2].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                lbl_fiyat_3.Text = edebiyat_source[2].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                img3.ImageUrl = edebiyat_source[2].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[2].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[2].yazar_id).yazar_soyisim;
                lbl_yazar_3.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[2].urun_id;
                link_3.NavigateUrl = link;
            }
            else if (edebiyat_source.Count < 5)
            {
                //Panel Kapatma
                pnl5.Visible = false;
                //---------------------------------------------
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                lbl_baslık_3.Text = edebiyat_source[2].urun_isim;
                lbl_baslık_4.Text = edebiyat_source[3].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                lbl_fiyat_3.Text = edebiyat_source[2].urun_fiyat.ToString() + " TL";
                lbl_fiyat_4.Text = edebiyat_source[3].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                img3.ImageUrl = edebiyat_source[2].urun_resim;
                img4.ImageUrl = edebiyat_source[3].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[2].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[2].yazar_id).yazar_soyisim;
                lbl_yazar_3.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[3].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[3].yazar_id).yazar_soyisim;
                lbl_yazar_4.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[2].urun_id;
                link_3.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[3].urun_id;
                link_4.NavigateUrl = link;
            }
            else if (edebiyat_source.Count < 6)
            {
                lbl_baslık_1.Text = edebiyat_source[0].urun_isim;
                lbl_baslık_2.Text = edebiyat_source[1].urun_isim;
                lbl_baslık_3.Text = edebiyat_source[2].urun_isim;
                lbl_baslık_4.Text = edebiyat_source[3].urun_isim;
                lbl_baslık_5.Text = edebiyat_source[4].urun_isim;
                //---------------------------------------------
                lbl_fiyat_1.Text = edebiyat_source[0].urun_fiyat.ToString() + " TL";
                lbl_fiyat_2.Text = edebiyat_source[1].urun_fiyat.ToString() + " TL";
                lbl_fiyat_3.Text = edebiyat_source[2].urun_fiyat.ToString() + " TL";
                lbl_fiyat_4.Text = edebiyat_source[3].urun_fiyat.ToString() + " TL";
                lbl_fiyat_5.Text = edebiyat_source[4].urun_fiyat.ToString() + " TL";
                //---------------------------------------------
                img1.ImageUrl = edebiyat_source[0].urun_resim;
                img2.ImageUrl = edebiyat_source[1].urun_resim;
                img3.ImageUrl = edebiyat_source[2].urun_resim;
                img4.ImageUrl = edebiyat_source[3].urun_resim;
                img5.ImageUrl = edebiyat_source[4].urun_resim;
                //---------------------------------------------
                yazarIsim = db.searchYazar(edebiyat_source[0].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[0].yazar_id).yazar_soyisim;
                lbl_yazar_1.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[1].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[1].yazar_id).yazar_soyisim;
                lbl_yazar_2.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[2].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[2].yazar_id).yazar_soyisim;
                lbl_yazar_3.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[3].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[3].yazar_id).yazar_soyisim;
                lbl_yazar_4.Text = yazarIsim;
                yazarIsim = db.searchYazar(edebiyat_source[4].yazar_id).yazar_isim + " " + db.searchYazar(edebiyat_source[4].yazar_id).yazar_soyisim;
                lbl_yazar_5.Text = yazarIsim;
                //---------------------------------------------
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[0].urun_id;
                link_1.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[1].urun_id;
                link_2.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[2].urun_id;
                link_3.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[3].urun_id;
                link_4.NavigateUrl = link;
                link = "kitapBilgisi.aspx?kitap_id=" + edebiyat_source[4].urun_id;
                link_5.NavigateUrl = link;
            }
        }

        public void setSourceList()
        {
            urunler = database.ürün.ToList();
            for (int i = 0; i < urunler.Count; i++)
            {
                if(i%5 != 0 || i == 0)
                {
                    urunler2.Add(urunler[i]);
                }
                else if (i%5 == 0)
                {
                    urunler_source.Add(urunler2);
                    urunler2.RemoveAt(0);
                    urunler2.RemoveAt(0);
                    urunler2.RemoveAt(0);
                    urunler2.RemoveAt(0);
                    urunler2.RemoveAt(0);
                    urunler2.Add(urunler[i]);

                }
                if (i == urunler.Count-1 && urunler2.Count != 0)
                {
                    urunler_source.Add(urunler2);
                }

            }           
        }

        protected void Repeater2_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            ürün a = (ürün)e.Item.DataItem;
            //int i = 1;
            Label lbl_siraNumarasi = (Label)e.Item.FindControl("lbl_siraNumarasi");
            Label lbl_baslık_1 = (Label)e.Item.FindControl("lbl_baslık_1");
            Label lbl_fiyat_1 = (Label)e.Item.FindControl("lbl_fiyat_1");
            Image img1 = (Image)e.Item.FindControl("img1");
            Label lbl_yazar_1 = (Label)e.Item.FindControl("lbl_yazar_1");
            HyperLink link = (HyperLink)e.Item.FindControl("link");
            String yazarIsim = "";
            String yayinIsim = "";
            yazarIsim = db.searchYazar(a.yazar_id).yazar_isim + " " + db.searchYazar(a.yazar_id).yazar_soyisim;
            yayinIsim = db.searchYayin(a.yayin_id).yayin_evi;

            lbl_baslık_1.Text = a.urun_isim.ToString();
            lbl_fiyat_1.Text = a.urun_fiyat.ToString() + " TL";
            img1.ImageUrl = a.urun_resim.ToString();
            lbl_yazar_1.Text = yazarIsim + " | " + yayinIsim;
            String linkS = "kitapBilgisi.aspx?kitap_id=" + a.urun_id.ToString();
            link.NavigateUrl = linkS;
            //lbl_siraNumarasi.Text = i.ToString();
            //i++;
        }
    }
        
}